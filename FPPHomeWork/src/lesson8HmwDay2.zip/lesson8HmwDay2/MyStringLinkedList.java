package lesson8HmwDay2;

public class MyStringLinkedList {
	Node header;

	MyStringLinkedList() {
		header = null;
	}

	public void addSort(String item) {
		{
			if (header == null) {
				header = new Node(null, item, null);
				return;
			}

			Node previous = null;
			Node current = header;
			Node newNode = null;

			while (current != null && item.compareTo(current.value) > 0) {
				previous = current;
				current = current.next;
			}
			if (previous == null) {
				newNode = new Node(null, item, current);
				header = newNode;
				header.next = current;

			} else

			{
				newNode = new Node(previous, item, current);
				previous.next = newNode;
				newNode.next = current;
			}
		}

	}

	public int size() {
		int count = 0;
		if (header != null) {
			while (header.next != null) {
				count++;
				header = header.next;
			}
		}
		return count;
	}

	public boolean isEmpty() {
		if (header == null)
			return true;
		else
			return false;
	}

	public Node getFirst() {
		return header.next;

	}

	public Node getLast() {
		if (header == null)
			return null;
		else {
			Node temp = header;
			while (temp.next != null)
				temp = temp.next;

			return temp;
		}

	}

	public void removeFirst() {
		if (header == null) {
			System.out.println("List is Empty can not delete.");
		}

		else if (header.next == null) 
			header = null;
		else {
			header.next.previous = null;
			header.next = header;
		}
	}

	void removeLast() {
		if (header == null)
			System.out.println("List is Empty can not delete.");
		else {
			Node temp = header;
			while (temp.next != null) {
				temp = temp.next;
				temp.previous.next = null;
				temp = null;
			}
		}
	}
	public boolean contains(String item) {
		
		if(item == null || isEmpty()) return false;
		Node temp = header;
		while(temp.next != null)
		{
			temp = temp.next;
			if(temp.value.equals(item)) return true;
		}

		return false;
	}

	public void print() {
		print(header);
	}

	private void print(Node n) {
		if (n == null)
			return;
		else {
			System.out.println(n.value);
			print(n.next);
		}

	}

	public String toString() {
		String str = "";
		Node temp = header;
		while (temp != null) {
			str = str + "-->[" + temp.value.toString() + "]";
			temp = temp.next;
		}
		str = str + "-->[" + "NULL" + "]";
		return str;
	}

	public class Node {
		String value;
		Node next;
		Node previous;

		Node(Node previous, String value, Node next) {
			this.previous = previous;
			this.value = value;
			this.next = next;
		}

		public String toString() {
			return value;
		}
	}

	public static void main(String[] args) {
		MyStringLinkedList mySL = new MyStringLinkedList();

		mySL.addSort("Merry");
		mySL.addSort("Hiwi");
		mySL.addSort("Beza");
		mySL.addSort("Blen");
		mySL.addSort("Sami");
		mySL.addSort("Sura");

		System.out.println("My Orignal list is: " + mySL);
		System.out.println("Print list using Recursive");
		mySL.print();
		System.out.println("My list size is: " + mySL.size());
		System.out.println("Checking if the list is empty...... " + mySL.isEmpty());
		System.out.println("The 1st node of the list is: " + mySL.getFirst());
		System.out.println("The last node of the list is: " + mySL.getLast());
		mySL.removeLast();
		System.out.println("Removed the last node from the list: " + mySL);
		mySL.removeFirst();
		System.out.println("Removed the first node from the list: " + mySL);

	}
}
